package rudy.flipkart.machineround.model;

public class Customer {

    private long customerId;
    private String customerName;

    public Customer(long customerId, String name) {
        this.customerId = customerId;
        this.customerName = name;
    }

    public long getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                '}';
    }
}
