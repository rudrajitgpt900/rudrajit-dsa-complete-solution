package rudy.flipkart.machineround.Main;

import rudy.flipkart.machineround.constants.ItemType;
import rudy.flipkart.machineround.model.Item;
import rudy.flipkart.machineround.service.CustomerService;
import rudy.flipkart.machineround.service.DriverService;
import rudy.flipkart.machineround.service.OrderService;

public class OrderPlacingApp {

    public static void main(String[] args) throws IllegalAccessException {

        // onboard Customer

        CustomerService customerService = new CustomerService();
        customerService.onboardCustomer(1, "Rudra");
        customerService.onboardCustomer(2,"Akash");
        customerService.onboardCustomer(3,"Mou");

        //Onboard Driver
        DriverService driverService = new DriverService();
        driverService.onboardDriver(1 ,"Pankaj");
        driverService.onboardDriver(2,"Shobhit");
        driverService.onboardDriver(3, "Nabendu");

        //Create Item customer wants to order
        Item item1 = new Item(1, "Jeans", ItemType.CLOTHES);
        Item item2 = new Item(2, "Paracetamol", ItemType.MEDICINES);

        //create an order;

        OrderService orderService = new OrderService();
       var order1= orderService.createOrder(1,item1);
       var order2 =  orderService.createOrder(2,item2);

        orderService.pickUpOrder(order1, order1.getAssignedDriver());
        orderService.completeOrder(order1 , order1.getAssignedDriver());
        orderService.printOrderStats(order1.getOrderId());
        orderService.printDriverStat(order1.getAssignedDriver().getDriverId());
    }
}
