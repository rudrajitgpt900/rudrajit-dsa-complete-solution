package rudy.flipkart.machineround.service;

import rudy.flipkart.machineround.constants.DriverStatus;
import rudy.flipkart.machineround.constants.ItemType;
import rudy.flipkart.machineround.constants.OrderStatus;
import rudy.flipkart.machineround.model.Customer;
import rudy.flipkart.machineround.model.Driver;
import rudy.flipkart.machineround.model.Item;
import rudy.flipkart.machineround.model.Order;
import rudy.flipkart.machineround.repository.BaseDataStore;
import rudy.flipkart.machineround.repository.OrderRepository;

import java.util.List;
import java.util.Objects;

/*
* create an order
* cancel an order
* show order status
* show driver status
* pickUp order
* completeOrder
*
* */
public class OrderService {
    private final DriverService driverService = new DriverService();
    private final CustomerService customerService = new CustomerService();


    public Order createOrder(long customerId, Item item) throws IllegalAccessException {
        Customer customer = customerService.getCustomer(customerId);
        if(Objects.isNull(customer)){
            throw new IllegalAccessException("Customer not found with given id :" + customerId);
        }
        if(!BaseDataStore.validate(item)){
            throw new IllegalAccessException("Only suggested Item types are allowed");
        }
        Order newOrder = new Order(customerId ,customerId , item);
        OrderRepository.addOrder(newOrder);

        //assignDriver from available driver
        //if driver available update driver status to assigned
        assignDriverIfAvailable(newOrder);

        return newOrder;
    }

    private void assignDriverIfAvailable(Order order){
        List<Driver> availableDrivers = driverService.getAvailableDrivers();
        Driver driverAvailable = availableDrivers.stream().filter(driver -> driver.getDriverStatus().equals(DriverStatus.AVAILABLE)).findFirst().orElseThrow(null);
        if(Objects.nonNull(driverAvailable)){
            order.setAssignedDriver(driverAvailable);
            driverAvailable.setDriverStatus(DriverStatus.ASSIGNED);
        }
        else{
            BaseDataStore.pendingOrder.add(order);
            System.out.println("No drivers Available rite now, We will assign once the drivers are available");
        }
    }

    public void cancelOrder(long orderId)  {
        Order existingOrder = OrderRepository.getOrderRepo().get(orderId);
        if(Objects.nonNull(existingOrder)){
            if( existingOrder.getOrderStatus().equals(OrderStatus.PICKED_UP) ){
                System.out.println("Order already picked up can't be cancelled now");
                return;
            }
            existingOrder.setOrderStatus(OrderStatus.CANCELLED);
            existingOrder.setAssignedDriver(null);
            OrderRepository.updateOrderRepo(existingOrder);
        }
    }

    public void pickUpOrder(Order order ,Driver driver){
        driver.setDriverStatus(DriverStatus.ON_TRIP);
        order.setOrderStatus(OrderStatus.PICKED_UP);

    }

    public void completeOrder(Order order , Driver driver){
        driverService.setDriverStatus(driver , DriverStatus.COMPLETED);
        order.setOrderStatus(OrderStatus.DELIVERED);
        driverService.setDriverStatus(driver , DriverStatus.AVAILABLE);
        driverService.getDriverRepo().put(driver.getDriverId(), driver);
    }

    public void printOrderStats(long orderId){
        var orderRepo = OrderRepository.getOrderRepo();
        if(orderRepo.containsKey(orderId)){
            System.out.println(orderRepo.get(orderId));
        }
    }

    public void printDriverStat(long driverId){
        var driverRepo = driverService.getDriverRepo();
        if(driverRepo.containsKey(driverId)){
            System.out.println(driverRepo.get(driverId));
        }
    }
}
